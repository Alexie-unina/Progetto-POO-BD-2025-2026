create function checkloginunivoco(new_login text) returns integer
    language plpgsql
as
$$
DECLARE
    numero INTEGER;
BEGIN
    SELECT COUNT(*) INTO numero
    FROM (
            SELECT Pilota.login
            FROM Pilota
            WHERE login = new_login
            UNION ALL
            SELECT Hostess.login
            FROM Hostess
            WHERE login = new_login
            UNION ALL
            SELECT Cliente.login
            FROM Cliente
            WHERE login = new_login
         );

    IF numero >= 1 THEN
    RAISE EXCEPTION 'Login gia'' esistente';
    END IF;

END;
$$;

alter function checkloginunivoco(text) owner to postgres;

