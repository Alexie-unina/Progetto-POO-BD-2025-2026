create function checkoverbooking() returns trigger
    language plpgsql
as
$$
DECLARE
    numeroPostiPrenotati INTEGER;
    numeroPostiAereo INTEGER;
BEGIN

    SELECT COUNT(IdPrenotazione) INTO numeroPostiPrenotati
    FROM Prenotazione
    WHERE NEW.idVolo = Prenotazione.idVolo;

    SELECT Aereo.nPosti INTO numeroPostiAereo
    FROM Volo
    JOIN Aereo
        ON Aereo.idAereo = Volo.idAereo
    WHERE Volo.idVolo = NEW.idVolo;


    IF (numeroPostiPrenotati >= ( NumeroPostiAereo * 1.10 ) ) THEN
       RAISE EXCEPTION 'Aereo Pienamente Prenotato!
       Posti Totali Aereo : %
       Posti gia Prenotati: %', numeroPostiAereo,numeroPostiPrenotati;
    END IF;

    RETURN NEW;

END;
$$;

alter function checkoverbooking() owner to postgres;

