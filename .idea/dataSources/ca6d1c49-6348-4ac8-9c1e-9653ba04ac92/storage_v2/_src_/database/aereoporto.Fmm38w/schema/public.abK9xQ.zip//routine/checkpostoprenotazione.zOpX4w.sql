create function checkpostoprenotazione() returns trigger
    language plpgsql
as
$$
DECLARE
    numeroStessoClientePosto INTEGER;
    numeroTotalePosto INTEGER;
BEGIN
    -- A) stesso cliente non può prenotare lo stesso posto due vol1te sullo stesso volo
    SELECT COUNT(*) INTO numeroStessoClientePosto
    FROM Prenotazione
    WHERE idVolo = NEW.idVolo
      AND posto = NEW.posto
      AND idCliente = NEW.idCliente;

    IF numeroStessoClientePosto >= 1 THEN
        RAISE EXCEPTION 'Il cliente ha gia'' prenotato questo posto su questo volo';
    END IF;

    -- B) lo stesso posto può essere prenotato al massimo 2 volte sullo stesso volo
    SELECT COUNT(*) INTO numeroTotalePosto
    -- Conta quante volte lo stesso posto è già stato prenotato per questo volo
    FROM Prenotazione
    WHERE idVolo = NEW.idVolo
      AND posto = NEW.posto;

    IF numeroTotalePosto >= 2 THEN
        RAISE EXCEPTION 'Posto % gia'' prenotato il numero massimo di volte su questo volo', NEW.posto;
    END IF;

    RETURN NEW;
END;
$$;

alter function checkpostoprenotazione() owner to postgres;

