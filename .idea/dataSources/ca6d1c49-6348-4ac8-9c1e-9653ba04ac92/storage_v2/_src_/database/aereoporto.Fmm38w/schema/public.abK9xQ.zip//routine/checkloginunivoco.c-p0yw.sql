create function checkloginunivoco() returns trigger
    language plpgsql
as
$$
DECLARE
    numero INTEGER;
BEGIN
    IF EXISTS (
        SELECT 1
        FROM Cliente
        WHERE login = new.login
        UNION ALL
        SELECT 1
        FROM Hostess
        WHERE login = new.login
        UNION ALL
        SELECT 1
        FROM Pilota
        WHERE login = new.login
    ) THEN
        RAISE EXCEPTION 'Login % gia'' esistente', new.login;
    END IF;

    RETURN NEW;
END;
$$;

alter function checkloginunivoco() owner to postgres;

